export const config = {
    developer: {
        name: "Eshwar",
        fullName: "Eshwar Reddy Gali",
        title: "Engineer",
        description: "Engineer working across interior design coordination, site engineering, and infrastructure documentation. Experienced in client-facing design work, estimation & billing, procurement, and land management documentation with premium clients and public-sector organizations."
    },
    social: {
        github: "eshwarreddy24",
        email: "eshwarreddy.gali@outlook.com",
        location: "Bengaluru, India"
    },
    about: {
        title: "About Me",
        description: "I'm an engineer with hands-on experience spanning interior design and public infrastructure. As a Graduate Engineer Trainee at Organo Eco Habitats, I worked on interior design and drafting, coordinated with premium NRI clients, handled estimation and billing for interior works, and contributed to quarterly growth reports and a published case study on sustainable bamboo-shade design. I'm currently a Graduate Apprentice at the Airports Authority of India (Bengaluru International Airport), where I work on land-management documentation, SAP MM billing entries, tendering & procurement, GeM portal operations, and official letter drafting — coordinating with senior officials and 150+ vendor companies. Along the way I've explored GAGAN (ISRO-AAI satellite navigation), IOCL fuelling systems, HAL Airport infrastructure, and DGPS surveying, and I'm proficient in AutoCAD, SketchUp, MS Office, and Adobe design tools."
    },
    experiences: [
        {
            position: "Graduate Apprentice",
            company: "Airports Authority of India (AAI) — Bengaluru International Airport",
            period: "Present",
            location: "Bengaluru, India",
            description: "Handling documentation, land-management case studies, and billing for AAI's maintenance and infrastructure works, while coordinating tendering and procurement with vendor companies and senior officials.",
            responsibilities: [
                "Documentation and case studies on land management at Bengaluru International Airport land records",
                "Drafted official letters to premium PSU companies, coordinating with Ex-IPS and Ex-IAS officers",
                "SAP MM billing entries for maintenance and infrastructure works",
                "Tendering & procurement: collected quotations, scrutinized 150+ vendor (MSME) tenders, prepared Justification Statements and CPP tender documents",
                "Worked on GeM portal, e-Office (govt EDMS), and MIS reporting; drafted Hindi official-language correspondence",
                "Explored GAGAN (ISRO-AAI satellite navigation), IOCL fuelling systems, HAL Airport infrastructure, and DGPS surveying; briefed on ATC and AOCC functions during airport familiarisation with Jt. GMs and GMs"
            ],
            technologies: ["SAP MM", "GeM Portal", "e-Office", "MS Excel", "Tendering", "MIS Reporting", "Documentation"]
        },
        {
            position: "Graduate Engineer Trainee",
            company: "Organo Eco Habitats Pvt Ltd",
            period: "Previous",
            location: "India",
            description: "Worked on interior design and site coordination for premium NRI clients, handling design presentations, estimation, and billing, while contributing to company growth reporting.",
            responsibilities: [
                "Interior design, drafting, and design presentations for premium NRI clients, coordinated via ClickUp",
                "Site coordination engineer — clarified client requirements and resolved on-site queries",
                "Estimation and billing for interior works",
                "Contributed to quarterly company growth reports, presented to the board",
                "Co-authored a published case study, \"Cool Shade, Smarter Spaces\", on a bamboo-shade roof structure showing up to 17°C cooler surface temperatures and ~90% lower long-term cost versus steel/concrete pergolas"
            ],
            technologies: ["AutoCAD", "SketchUp", "ClickUp", "Estimation", "Billing", "Client Coordination"]
        },
        {
            position: "B.Tech + Student Leadership",
            company: "Shutterbugs Club, NSS & AIC-SKU",
            period: "College",
            location: "India",
            description: "Alongside engineering coursework, led a 20+ member student cinematography club, completed NSS volunteering, and was selected for an entrepreneurship incubation cohort.",
            responsibilities: [
                "Led Shutterbugs, a 20-member student cinematography & video editing club; captured and produced the college graduation ceremony",
                "Completed a 2-month NSS programme, certified as an NSS volunteer",
                "Team leader for a college-wide Startup Innovation Challenge pitch, selected among all participating teams",
                "Completed AIC-SKU (Atal Incubation Centre) entrepreneurship development training, Cohort 3.0, mentored by Naveen Lakkur",
                "Coursework in Advanced Excel and the MS Office suite"
            ],
            technologies: ["MS Office", "Advanced Excel", "Video Editing", "Leadership"]
        }
    ],
    contact: {
        email: "eshwarreddy.gali@outlook.com",
        phone: "+91 9515291117",
        github: "https://github.com/eshwarreddy24",
        linkedin: "https://www.linkedin.com/in/eshwar-reddy-gali-",
        instagram: "https://www.instagram.com/eshwarrxddy"
    },
    skills: {
        develop: {
            title: "DESIGN & DRAFTING",
            description: "Interior design, drafting & visualization",
            details: "Designing and drafting interior spaces for premium clients, from concept to presentation. Comfortable across CAD drafting, 3D visualization, and creative software for polished client-ready presentations.",
            tools: ["AutoCAD", "SketchUp", "Unreal Engine", "Photoshop", "Premiere Pro", "ClickUp", "MS Office", "Design Presentation"]
        },
        design: {
            title: "DOCUMENTATION & ESTIMATION",
            description: "Billing, estimation & procurement documentation",
            details: "Handling estimation, billing, and procurement documentation for interior and infrastructure works — from BOQs and SAP MM entries to tender scrutiny and official correspondence.",
            tools: ["MS Excel", "BOQ & Estimation", "SAP MM", "GeM Portal", "e-Office", "Tendering", "MIS Reporting", "Site Coordination"]
        }
    }
};


