import "./styles/TechStackNew.css";

interface TechItem {
  name: string;
  icon: string;
  url: string;
}

// Software & tools used across design, visualization, and documentation work
const techStack: TechItem[] = [
  {
    name: "AutoCAD",
    icon: "https://cdn.jsdelivr.net/npm/simple-icons@v13/icons/autocad.svg",
    url: "https://www.autodesk.com/products/autocad/overview",
  },
  {
    name: "SketchUp",
    icon: "https://cdn.jsdelivr.net/npm/simple-icons@v13/icons/sketchup.svg",
    url: "https://www.sketchup.com",
  },
  {
    name: "Unreal Engine",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/unrealengine/unrealengine-original.svg",
    url: "https://www.unrealengine.com",
  },
  {
    name: "Photoshop",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/photoshop/photoshop-original.svg",
    url: "https://www.adobe.com/products/photoshop.html",
  },
  {
    name: "Premiere Pro",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/premierepro/premierepro-original.svg",
    url: "https://www.adobe.com/products/premiere.html",
  },
  {
    name: "MS Office",
    icon: "https://img.icons8.com/color/96/microsoft-office-2019.png",
    url: "https://www.microsoft.com/microsoft-365",
  },
  {
    name: "GitHub",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/github/github-original.svg",
    url: "https://github.com",
  },
  {
    name: "Vercel",
    icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vercel/vercel-original.svg",
    url: "https://vercel.com",
  },
];

const TechStackNew = () => {
  return (
    <div className="techstack-new">
      {/* Video Background */}
      <div className="techstack-video-container">
        <video autoPlay loop muted playsInline className="techstack-video">
          <source src="/video/video.webm" type="video/webm" />
        </video>
        {/* Dark Overlay */}
        <div className="techstack-overlay"></div>
      </div>

      {/* Content */}
      <div className="techstack-content">
        <h2>Tools &amp; Software</h2>

        <div className="techstack-grid">
          {techStack.map((tech, index) => (
            <a
              key={index}
              href={tech.url}
              target="_blank"
              rel="noopener noreferrer"
              className="techstack-gem"
              title={tech.name}
              data-cursor="disable"
            >
              <span className="techstack-gem-shape">
                <img src={tech.icon} alt={tech.name} loading="lazy" decoding="async" />
              </span>
              <span className="techstack-gem-label">{tech.name}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TechStackNew;
