import { PropsWithChildren } from "react";
import "./styles/Landing.css";
import { config } from "../config";

const Landing = ({ children }: PropsWithChildren) => {
  const nameParts = config.developer.fullName.split(" ");
  const firstName = nameParts[0] || config.developer.name;
  const lastName = nameParts.slice(1).join(" ") || "";
  const initials = nameParts.map((part) => part[0]).join("").toUpperCase();

  return (
    <>
      <div className="landing-section" id="landingDiv">
        <div className="landing-container">
          <div className="landing-intro">
            <h2>Hello! I'm</h2>
            <h1>
              {firstName.toUpperCase()}
              {' '}
              <br />
              {lastName && <span>{lastName.toUpperCase()}</span>}
            </h1>
          </div>
          <div className="landing-info">
            <h3>An</h3>
            <h2 className="landing-info-h2">
              <div className="landing-h2-1">{config.developer.title}</div>
            </h2>
            <h2>
              <div className="landing-h2-info">Design, Documentation &amp; Estimation</div>
            </h2>
          </div>
          {/* Mobile placeholder - shows only on mobile when 3D character is hidden */}
          <div className="mobile-photo">
            <div className="mobile-photo-monogram" aria-hidden="true">
              <span>{initials}</span>
            </div>
          </div>
        </div>
        {children}
      </div>
    </>
  );
};

export default Landing;
